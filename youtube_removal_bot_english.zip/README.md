# YouTube Removal Monitor

English-language Discord bot that monitors YouTube videos and alerts a Discord channel when a monitored video becomes unavailable.

## Commands

- `/watch <YouTube URL>` - Start monitoring a video.
- `/unwatch <YouTube URL>` - Stop monitoring a video.
- `/list` - Show monitored videos.

## Render

Recommended service type: **Background Worker**.

Build command:
`pip install -r requirements.txt`

Start command:
`python bot.py`

Environment variables:
- `DISCORD_TOKEN`
- `YOUTUBE_API_KEY`
- `CHECK_INTERVAL_MINUTES=5`
- `DATABASE=/var/data/bot.db`

Use a Persistent Disk mounted at `/var/data` if you want the SQLite database to survive restarts.

Never put your Discord token or YouTube API key in GitHub.
